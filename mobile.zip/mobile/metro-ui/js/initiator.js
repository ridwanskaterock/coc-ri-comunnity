$.fn.reverse = Array.prototype.reverse;

$.Metro = function(params){
    params = $.extend({
    }, params);
};

$.Metro.hotkeys = [];

$.Metro.initWidgets = function(){
    var widgets = $("[data-role]");

    var hotkeys = $("[data-hotkey]");
    $.each(hotkeys, function(){
        var element = $(this);
        var hotkey = element.data('hotkey').toLowerCase();

        //if ($.Metro.hotkeys.indexOf(hotkey) > -1) {
        //    return;
        //}
        if (element.data('hotKeyBonded') === true ) {
            return;
        }

        $.Metro.hotkeys.push(hotkey);

        $(document).on('keyup', null, hotkey, function(e){
            if (element === undefined) return;

            if (element[0].tagName === 'A' &&
                element.attr('href') !== undefined &&
                element.attr('href').trim() !== '' &&
                element.attr('href').trim() !== '#') {
                document.location.href = element.attr('href');
            } else {
                element.click();
            }
            return false;
        });

        element.data('hotKeyBonded', true);
    });

    $.each(widgets, function(){
        var $this = $(this), w = this;
        var roles = $this.data('role').split(/\s*,\s*/);
        roles.map(function(func){
            try {
                //$(w)[func]();
                if ($.fn[func] !== undefined && $this.data(func+'-initiated') !== true) {
                    $.fn[func].call($this);
                    $this.data(func+'-initiated', true);
                }
            } catch(e) {
                if (window.METRO_DEBUG) {
                    console.log(e.message, e.stack);
                }
            }
        });
    });
};

$.Metro.init = function(){
    $.Metro.initWidgets();

    if (window.METRO_AUTO_REINIT) {
        if (!window.canObserveMutation) {
            var originalDOM = $('body').html(),
                actualDOM;

            setInterval(function () {
                actualDOM = $('body').html();

                if (originalDOM !== actualDOM) {
                    originalDOM = actualDOM;

                    $.Metro.initWidgets();
                }
            }, 100);
        } else {
            var observer, observerOptions, observerCallback;
            observerOptions = {
                'childList': true,
                'subtree': true
            };
            observerCallback = function(mutations){

                //console.log(mutations);

                mutations.map(function(record){

                    if (record.addedNodes) {

                        /*jshint loopfunc: true */
                        var obj, widgets, plugins, hotkeys;

                        for(var i = 0, l = record.addedNodes.length; i < l; i++) {
                            obj = $(record.addedNodes[i]);

                            plugins = obj.find("[data-role]");

                            hotkeys = obj.find("[data-hotkey]");

                            $.each(hotkeys, function(){
                                var element = $(this);
                                var hotkey = element.data('hotkey').toLowerCase();

                                //if ($.Metro.hotkeys.indexOf(hotkey) > -1) {
                                //    return;
                                //}

                                if (element.data('hotKeyBonded') === true ) {
                                    return;
                                }

                                $.Metro.hotkeys.push(hotkey);

                                $(document).on('keyup', null, hotkey, function () {
                                    if (element === undefined) return;

                                    if (element[0].tagName === 'A' &&
                                        element.attr('href') !== undefined &&
                                        element.attr('href').trim() !== '' &&
                                        element.attr('href').trim() !== '#') {
                                        document.location.href = element.attr('href');
                                    } else {
                                        element.click();
                                    }
                                    return false;
                                });

                                element.data('hotKeyBonded', true);
                                //console.log($.Metro.hotkeys);
                            });

                            if (obj.data('role') !== undefined) {
                                widgets = $.merge(plugins, obj);
                            } else {
                                widgets = plugins;
                            }

                            if (widgets.length) {
                                $.each(widgets, function(){
                                    var _this = $(this);
                                    var roles = _this.data('role').split(/\s*,\s*/);
                                    roles.map(function(func){
                                        try {
                                            if ($.fn[func] !== undefined && _this.data(func+'-initiated') !== true) {
                                                $.fn[func].call(_this);
                                                _this.data(func+'-initiated', true);
                                            }
                                        } catch(e) {
                                            if (window.METRO_DEBUG) {
                                                console.log(e.message, e.stack);
                                            }
                                        }
                                    });
                                });
                            }
                        }
                    }
                });
            };

            //console.log($(document));
            observer = new MutationObserver(observerCallback);
            observer.observe(document, observerOptions);
        }
    }
};
